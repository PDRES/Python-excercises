from setuptools import setup

setup(
	name="paquete",
	version="0.1",
	decription="Ejemplo",
	Author="PDRES", 
	email="none", 
	Web="In progress",
	sripts=[],
	packages=["paquete","paquete.execution","paquete.action"] 
	)