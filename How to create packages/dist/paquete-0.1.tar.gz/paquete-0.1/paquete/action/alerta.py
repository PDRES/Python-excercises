#module for clients in red number
#how to import modules or classes 

def alert():

	print("Client with no money")

class alerta_maxima():
	def __init__(self):
		print("Execute procedure 00")