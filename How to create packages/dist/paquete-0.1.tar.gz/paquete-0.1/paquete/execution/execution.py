#What to do when client with no money 

def execute():

	print("1 month warning .. then: ")

class execution():
	def __init__(self):
		print("Bank will keep your goods")